#include <stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char *argv[]){
pid_t processID;
processID = fork(); /* Create a child process */

	if (processID==0) /* If the process is a child process */
	{
		execv(argv[1],&argv[1]);
	}
	else
	{
		
		int processStatus;		
		waitpid(processID, &processStatus,0);
		printf("Parent process terminated with pid : %d",getpid());
        printf("\n");
	}
	
}
