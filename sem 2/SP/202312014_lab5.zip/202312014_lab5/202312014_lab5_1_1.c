#include <stdio.h>
#include<unistd.h>
int main()
{
printf("child process terminated with pid : %d", getpid());
printf("\n");
return 0;
}
