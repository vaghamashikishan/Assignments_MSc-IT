#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
	int processID,childProcessID;
	int exitStatus;
	processID = fork(); 
	if(processID==0)
	{
		execl("/bin/ls","ls","-l","-t","-r",NULL);
	}
	childProcessID = waitpid(processID,&exitStatus,0);
	printf("Child process %d exited with status %d\n", childProcessID, exitStatus);
	processID = fork();
	if(processID==0)
	{
		execlp("ls","ls","-l","-t","-r",NULL);
	}
	childProcessID = waitpid(processID,&exitStatus,0);
	printf("Child process %d exited with status %d\n", childProcessID, exitStatus);
	processID=fork();
	if(processID==0)
	{
		char* commandArgs[] = {"ls","-l","-t","-r"};
		execv("/bin/ls",commandArgs);
	}
	childProcessID = waitpid(processID,&exitStatus,0);
	printf("Child process %d exited with status %d\n", childProcessID, exitStatus);
	processID=fork();
	if(processID==0)
	{
		char* commandArgs[] = {"ls","-l","-t","-r"};
		execvp("ls",commandArgs);
	}
	childProcessID = waitpid(processID,&exitStatus,0);
	printf("Child process %d exited with status %d\n", childProcessID, exitStatus);
	return 0;
}
